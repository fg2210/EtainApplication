﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program z = new Program();
            Console.WriteLine("Please enter a number to display the Fibonacci sequence value:");
            int a = z.displayFibonacci(int.Parse(Console.ReadLine()));
            Console.WriteLine(a);
            Console.ReadKey();
        }

        public int displayFibonacci(int num)
        {
            int n = num - 1;
            int[] val = new int[n + 1];

            val[0] = 0;
            val[1] = 1;

            for (int i = 2; i <= n; i++)
            {
                val[i] = val[i - 2] + val[i - 1];
            }

            return val[n];
        }
    }
}
